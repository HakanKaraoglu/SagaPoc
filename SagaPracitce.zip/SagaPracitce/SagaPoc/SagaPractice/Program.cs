using System.Reflection;
using Company.StateMachines;
using MassTransit;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using SagaPractice.Consumers;
using SagaPractice.DbContext;
using SagaPractice.Publisher;
using SagaPractice.StateMachines;

var host = Host.CreateDefaultBuilder(args)
    .ConfigureServices((hostContext, services) =>
    {
        services.AddMassTransit(cfg =>
        {
            cfg.AddSagaStateMachine<BurgerCookerStateMachine, BurgerCookerStateInstance>().EntityFrameworkRepository(opt =>
            {
                opt.AddDbContext<DbContext, BurgerSagaDbContext>((provider, builder) =>
                {
                    builder.UseNpgsql(hostContext.Configuration.GetConnectionString("DefaultConnection"),
                        m => { m.MigrationsAssembly(Assembly.GetExecutingAssembly().GetName().Name); });
                    
                   // endpointConfigurator.UseEntityFrameworkOutbox<BurgerSagaDbContext>(endpointConfigurator);
                });

                opt.ConcurrencyMode = ConcurrencyMode.Optimistic;
            });

            cfg.AddConsumer<CookBurgerConsumer>();

            cfg.UsingInMemory((context, cfg) =>
            {
                cfg.ConfigureEndpoints(context);
                cfg.PrefetchCount = 1;
            });

            cfg.AddHostedService<OrderPublisher>();
        });
    })
    .Build();

host.Run();