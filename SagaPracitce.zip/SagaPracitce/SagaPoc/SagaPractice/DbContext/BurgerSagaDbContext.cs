using System.Collections.Generic;
using MassTransit.EntityFrameworkCoreIntegration;
using Microsoft.EntityFrameworkCore;
using SagaPractice.StateMap;

namespace SagaPractice.DbContext
{
    public class BurgerSagaDbContext : SagaDbContext
    {
        public BurgerSagaDbContext(DbContextOptions<BurgerSagaDbContext> options) : base(options)
        {
        }

        protected override IEnumerable<ISagaClassMap> Configurations
        {
            get { yield return new BurgerStateMap(); }
        }
    }
}