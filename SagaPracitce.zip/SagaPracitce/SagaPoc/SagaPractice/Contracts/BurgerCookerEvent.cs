namespace Contracts
{
    using System;

    public class BurgerCookerOrderedEvent
    {
        public Guid CorrelationId { get; set; }
        public string CustomerName { get; set; }
        public string CookTemp { get; set; }
    }
}