using System;

namespace Contracts
{
    public class BurgerCookerBeginCookingEvent
    {
        public Guid CorrelationId { get; set; }
        public string CustomerName { get; set; }
        public string CookTemp { get; set; }
    }
}