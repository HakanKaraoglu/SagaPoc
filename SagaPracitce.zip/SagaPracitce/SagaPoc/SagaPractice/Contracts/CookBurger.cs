using System;

namespace SagaPractice.Contracts
{
    public class CookBurger
    {
        public Guid CorrelationId { get; set; }
        public string CustomerName { get; set; }
        public string CookTemp { get; set; }
    }
}