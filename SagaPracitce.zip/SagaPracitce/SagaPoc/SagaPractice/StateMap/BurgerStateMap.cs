using MassTransit;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SagaPractice.StateMachines;

namespace SagaPractice.StateMap
{
    public class BurgerStateMap : SagaClassMap<BurgerCookerStateInstance>
    {
        // protected override void Configure(EntityTypeBuilder<BurgerCookerStateInstance> entity, ModelBuilder model)
        // {
        //     entity.Property(x => x.CurrentState).HasMaxLength(50);
        //     entity.Property(x => x.CustomerName).HasMaxLength(255);
        //     // Diğer özellikler için gerekli konfigürasyonlar...
        //
        //     entity.HasIndex(x => x.CustomerName);
        // }
        
        protected override void Configure(EntityTypeBuilder<BurgerCookerStateInstance> entity, ModelBuilder model)
        {
            // entity.Property(x => x.CustomerId).HasMaxLength(256);
        }
    }
}