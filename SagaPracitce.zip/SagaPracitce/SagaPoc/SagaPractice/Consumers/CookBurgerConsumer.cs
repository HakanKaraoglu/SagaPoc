using System;
using System.Threading;
using System.Threading.Tasks;
using MassTransit;
using SagaPractice.Contracts;

namespace SagaPractice.Consumers
{
    public class CookBurgerConsumer : IConsumer<CookBurger>
    {
        public Task Consume(ConsumeContext<CookBurger> context)
        {
            if (context.Message.CookTemp.Equals("Rare"))
            {
                Thread.Sleep(2000);
            }
            else if (context.Message.CookTemp.Equals("Med"))
            {
                Thread.Sleep(5000);
            }
            else if (context.Message.CookTemp.Equals("Burned"))
            {
                Thread.Sleep(10000);
            }

            var bcfce = new BurgerCookerBeginFinishCookingEvent()
            {
                CorrelationId = context.Message.CorrelationId,
                CustomerName = context.Message.CustomerName,
                CookTemp = context.Message.CookTemp
            };
            
            context.Publish(bcfce);

            //Console.WriteLine($"Getting ready. InvoiceId : {context.Message.CorrelationId}, Customer Name : {context.Message.CustomerName}, Cook Temp : {context.Message.CookTemp}  ");
            
            return Task.CompletedTask;
        }
    }
}