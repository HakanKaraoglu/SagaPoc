using System;
using MassTransit;

namespace SagaPractice.StateMachines
{
    public class BurgerCookerStateInstance : SagaStateMachineInstance
    {
        
        public int CurrentState { get; set; }

        public string CustomerName { get; set; }
        
        public string CookTemp { get; set; }

        public Guid CorrelationId { get; set; }
    }
}