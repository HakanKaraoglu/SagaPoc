using System;
using SagaPractice.Contracts;
using SagaPractice.StateMachines;

namespace Company.StateMachines
{
    using Contracts;
    using MassTransit;

    public class BurgerCookerStateMachine : MassTransitStateMachine<BurgerCookerStateInstance>
    {
        public BurgerCookerStateMachine()
        {
            this.InstanceState(x => x.CurrentState, Ordered);
            this.ConfigureCorrelationIds();

            Initially(
                When(BurgerCookerOrderedEvent)
                    .Then(context =>
                    {
                        context.Saga.CustomerName = context.Message.CustomerName;
                        context.Saga.CookTemp = context.Message.CookTemp;

                        Console.WriteLine($"Incoming order information. State: {context.Saga.CurrentState} InvoiceId : {context.Saga.CorrelationId}, Customer Name : {context.Saga.CustomerName}, Cook Temp : {context.Saga.CookTemp}  ");

                        var bcbce = new BurgerCookerBeginCookingEvent
                        {
                            CorrelationId = context.Saga.CorrelationId,
                            CustomerName = context.Saga.CustomerName,
                            CookTemp = context.Saga.CookTemp
                        };

                        context.Publish(bcbce);
                    })
                    .TransitionTo(BeginCooking)
            );

            During(BeginCooking,
                When(BurgerCookerBeginCookingEvent)
                    .Then(context =>
                    {
                        var cb = new CookBurger { CookTemp = context.Message.CookTemp, CustomerName = context.Message.CustomerName, CorrelationId = context.Message.CorrelationId };
                        context.Publish(cb);

                        Console.WriteLine($"Getting ready. State: {context.Saga.CurrentState} InvoiceId : {context.Saga.CorrelationId}, Customer Name : {context.Saga.CustomerName}, Cook Temp : {context.Saga.CookTemp}  ");
                    })
                    .TransitionTo(FinishCooking)
            );
            During(FinishCooking,
                When(BurgerCookerFinishCookingEvent)
                    .Then(context => { Console.WriteLine($"Order completed.. State: {context.Saga.CurrentState} InvoiceId : {context.Saga.CorrelationId}, Customer Name : {context.Saga.CustomerName}, Cook Temp : {context.Saga.CookTemp}  "); })
                    .TransitionTo(Completed)
                    .Finalize()
            );

            SetCompletedWhenFinalized();
        }

        private void ConfigureCorrelationIds()
        {
            this.Event(() => BurgerCookerOrderedEvent, x => x.CorrelateById(context => context.Message.CorrelationId));
            this.Event(() => BurgerCookerBeginCookingEvent, x => x.CorrelateById(context => context.Message.CorrelationId));
            this.Event(() => BurgerCookerFinishCookingEvent, x => x.CorrelateById(context => context.Message.CorrelationId));
        }

        public State Ordered { get; private set; }

        public State BeginCooking { get; private set; }

        public State FinishCooking { get; private set; }

        public State Completed { get; private set; }

        public Event<BurgerCookerOrderedEvent> BurgerCookerOrderedEvent { get; private set; }

        public Event<BurgerCookerBeginCookingEvent> BurgerCookerBeginCookingEvent { get; private set; }

        public Event<BurgerCookerBeginFinishCookingEvent> BurgerCookerFinishCookingEvent { get; private set; }
    }
}