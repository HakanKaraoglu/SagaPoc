using SagaPractice.DbContext;
using SagaPractice.StateMachines;

namespace Company.StateMachines
{
    using MassTransit;

    public class BurgerCookerStateSagaDefinition : SagaDefinition<BurgerCookerStateInstance>
    {
        protected override void ConfigureSaga(IReceiveEndpointConfigurator endpointConfigurator, ISagaConfigurator<BurgerCookerStateInstance> sagaConfigurator)
        {
            endpointConfigurator.UseMessageRetry(r => r.Intervals(500, 1000));
            endpointConfigurator.PrefetchCount = 1;
            endpointConfigurator.ConcurrentMessageLimit = 1;
        }
    }
}