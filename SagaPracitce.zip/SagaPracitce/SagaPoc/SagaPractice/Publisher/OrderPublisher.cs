using System;
using System.Threading;
using System.Threading.Tasks;
using Contracts;
using MassTransit;
using Microsoft.Extensions.Hosting;

namespace SagaPractice.Publisher
{
    public class OrderPublisher : BackgroundService
    {
        private readonly IBus _bus;

        public OrderPublisher(IBus bus)
        {
            _bus = bus;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                await _bus.Publish(new BurgerCookerOrderedEvent
                {
                    CorrelationId = Guid.NewGuid(),
                    CustomerName = GetRandomName(),
                    CookTemp = GetRandomTemp(),
                }, stoppingToken);

                await Task.Delay(10000, stoppingToken);
            }
        }

        private string GetRandomName()
        {
            string[] names = { "John", "Michael", "Sara", "Emily", "David", "Daniel", "Emma", "Olivia", "Sophia" };
            var randomName = GetRandom(names);
            return randomName;
        }

        private string GetRandomTemp()
        {
            string[] temp = { "Rare", "Med", "Burned" };
            var randomTemp = GetRandom(temp);
            return randomTemp;
        }

        static string GetRandom(string[] array)
        {
            // Random nesnesi oluşturma
            var random = new Random();

            // İsim listesinden rastgele bir indeks seçme
            var randomIndex = random.Next(array.Length);

            // Seçilen indeksteki ismi döndürme
            return array[randomIndex];
        }
    }
}